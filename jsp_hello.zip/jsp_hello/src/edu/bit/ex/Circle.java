package edu.bit.ex;

public class Circle {
	
	public Circle() {
		System.out.println("������");
	}
	
	public double getArea(double radius) {
		return radius * radius * Math.PI;
	}
	
}
