package edu.bit.ex.service;

import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.inject.Inject;

import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import edu.bit.ex.mapper.UserMapper;
import edu.bit.ex.vo.UserVO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.log4j.Log4j;

@Log4j
@NoArgsConstructor
@Service
//@AllArgsConstructor - �ȸ��� ���� �־�->inject�� ����
public class UserService {
	
	@Inject
	private BCryptPasswordEncoder passEncoder;
	
	
	@Inject
	private UserMapper mapper;
	
	public void addUser(UserVO userVO) {
		String password = userVO.getPassword();
		String encode = passEncoder.encode(password);
		
		userVO.setPassword(encode);
		
			mapper.insertUser(userVO);
			mapper.insetAuthorities(userVO);
		}
	}
	
	

