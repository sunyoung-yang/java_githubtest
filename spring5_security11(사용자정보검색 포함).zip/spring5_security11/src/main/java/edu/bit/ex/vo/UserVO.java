package edu.bit.ex.vo;

import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.log4j.Log4j;

@Log4j
@AllArgsConstructor
@Getter
@Setter
public class UserVO {
	
	private String username;
	private String password;
	private int enabled;
	
	public UserVO() {
		this("user","1111",1);
	}
}
