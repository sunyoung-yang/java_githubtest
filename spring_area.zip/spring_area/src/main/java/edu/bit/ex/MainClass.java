package edu.bit.ex;



import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		
	//�л����� �ߴ°�
		 /* String config = "classpath:studentapplicationCTX.xml";
		 * AbstractApplicationContext ctx = new GenericXmlApplicationContext(config); //
		 * 
		 * StudentInfo studentInfo = ctx.getBean("studentInfo",StudentInfo.class);
		 * 
		 * studentInfo.getStudentInfo();
		 * 
		 * Student student2 = ctx.getBean("student2",Student.class);
		 * studentInfo.setStudent(student2); studentInfo.getStudentInfo(); ctx.close();
		 */
		
		
			/*
			 * String config = "classpath:apppencilCTX.xml"; AbstractApplicationContext ctx
			 * = new GenericXmlApplicationContext(config);
			 * 
			 * Pencil pencil = ctx.getBean("pencil",Pencil.class); pencil.use();
			 * 
			 * ctx.close();
			 */
		
		String config = "classpath:apppencilCTX.xml"; 
		AbstractApplicationContext ctx = new GenericXmlApplicationContext(config);
		
		Area area = ctx.getBean("area1",Area.class);
		System.out.println(area.getArea(10,10.5));
		ctx.close();
		
		
	
	}
	
}
