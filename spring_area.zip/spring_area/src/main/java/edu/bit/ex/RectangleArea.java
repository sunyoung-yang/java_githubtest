package edu.bit.ex;

public class RectangleArea implements Area {

	double width;
	double height;
	
	
	
	// ��l��Ʈ �����ڴ� �ݵ�� �����ؾ� �Ѵ�.
	public RectangleArea() {}
	
	public RectangleArea(double width, double height) {
		super();
		this.width = width;
		this.height = height;
	}
	
	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	 @Override
		public double getArea(double width,double height) {
			
		 return width*height;
	 }
	  @Override 
	  public double getArea() {
	  
		  return width*height; 
		  }
	

	}

