package edu.bit.ex;

public class TriangleArea implements Area {

	double width;
	double height;
	
	public TriangleArea() {}
	
	public TriangleArea(double width, double height) {
		super();
		this.width = width;
		this.height = height;
	}


	
	  public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	@Override 
	  public double getArea() {
	  double result = (width*height)/2; 
	  return result;
	  
	 }
	
	
	@Override
	public double getArea(double width,double height) {
		
		return (width*height)/2;

	}
}