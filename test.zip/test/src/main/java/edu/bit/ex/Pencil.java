package edu.bit.ex;

public interface Pencil {
	
	public void use();

	
}
