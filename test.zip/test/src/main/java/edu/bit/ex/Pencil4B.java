package edu.bit.ex;

public class Pencil4B implements Pencil {
	
	@Override
	public void use() {
		System.out.println("4B�Դϴ�.");
		
	}	
}
