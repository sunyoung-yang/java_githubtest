package edu.bit.ex;

public class Pencil6B implements Pencil {
	
	@Override
	public void use() {
		System.out.println("6B�Դϴ�.");
		
	}	
}
